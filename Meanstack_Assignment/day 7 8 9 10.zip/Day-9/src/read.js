const promise = require("bluebird");
const mysql = require("mysql");

promise.promisifyAll(require("mysql/lib/Connection").prototype);
promise.promisifyAll(require("mysql/lib/Pool").prototype);

let readdata = async() => {
    const connection=mysql.createConnection({
        user: "root",
        host: "localhost",
        database: "cdac20",
        password: ""
    });

    await connection.connectAsync();

    let sql = "select * from db";

    let result=    await connection.queryAsync(sql);

    await connection.endAsync();

    return result;
};

module.exports= {readdata};