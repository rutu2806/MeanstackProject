const promise = require("bluebird");
const mysql = require("mysql");

promise.promisifyAll(require("mysql/lib/Connection").prototype);
promise.promisifyAll(require("mysql/lib/Pool").prototype);

let adddata = async(inp) => {

    const connection= mysql.createConnection({

        user : "root",
        host: "localhost",
        database: "cdac20",
        password: ""
    });

    await connection.connectAsync();

    let sql = "insert into db (name,password) values(?,?)";
    await connection.queryAsync(sql,[inp.name,inp.password]);

    await connection.endAsync();
    
    return;
};

module.exports={adddata};