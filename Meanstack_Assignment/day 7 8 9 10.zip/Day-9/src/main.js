const promise = require("bluebird");
const mysql = require("mysql");

promise.promisifyAll(require("mysql/lib/Connection").prototype);
promise.promisifyAll(require("mysql/lib/Pool").prototype);

const express= require("express");
const app=express();

const dbadd = require("./db.add");
const dbread = require("./db.read");

app.get("/",async(req,res)=> {

    try{

        const username=req.querry.name;
        const password= req.query.password;

        const connection=mysql.createConnection({
            user: "root",
            host: "localhost",
            database: "cdac20",
            password: ""
        });

        await connection.connectAsync();

        let sql= "insert into (name,password) values (?,?)";

        await connection.queryAsync(sql,["ak","987"]);

        await connection.endAsync();

        const json= {message: "reccord added"};

        res.json(json);
    }

    catch(err){
        const json = {message: "error"};
        res.json(json);
    }
});


app.get("/adduser",async(req,res)=>{

    try{
        const input= req.query;
        await dbadd.addRecord(input);

        const json ={message:"success"};
        res.json(json);

    }
    catch(err){
        const json={message: "failed"};
        res.json(json);
    }
});

app.listen(3000);