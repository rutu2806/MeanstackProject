const promise= require("bluebird");
const mysql= require("mysql");

promise.promisifyAll(require("mysql/lib/Connection").prototype);
promise.promisifyAll(require("mysql/lib/Pool").prototype);

let readalluser = async() => {
  try{

    console.log("i am about to read db")
    const connection=mysql.createConnection({
        host: "localhost",
        user: "root",
        database: "cdac20",
        password: "",
    });
    await connection.connectAsync();
    console.log("connection successful");

    await connection.endAsync();
  }

  catch(err){
    console.log(err);
  }

};
readalluser();




// const Promise = require("bluebird");
// const mysql = require("mysql");

// // Promisify the mysql
// Promise.promisifyAll(require("mysql/lib/Connection").prototype);
// Promise.promisifyAll(require("mysql/lib/Pool").prototype);

// let readAllUser = async () => {
//   try {
//     console.log("I.AM.ABOUT.TO.READ.DB");

//     // STEP::1 :: CONNECT WITH DATBASE USNG CREDENTIAL
//     const connection = mysql.createConnection({
//       host: "localhost",
//       user: "root",
//       password: "",
//       database: "cdac20",
//     });

//     // connection.connect();  // normal method from mysql module
//     await connection.connectAsync(); // because of bluebird :: Promisified method

//     console.log("CONNECTION.SUCCESSFUL!!");

//     await connection.endAsync();
//   } catch (err) {
//     console.log(err);
//   }
// };

// readAllUser();