const promise= require("bluebird");
const mysql= require("mysql");

promise.promisifyAll(require("mysql/lib/Connection").prototype);
promise.promisifyAll(require("mysql/lib/Pool").prototype);

let dbconfig={
    user: "root",
    host: "localhost",
    database: "cdac20",
    password: ""
};

let read= async() => {

    const Connection=mysql.createConnection(dbconfig);

    await Connection.connectAsync();

    let sql = "Select * from db where name=? and id=?" ;

    let result= await Connection.queryAsync(sql,["ashish","1"]);

    console.log(result);

    Connection.endAsync();

    return result;

};

read();