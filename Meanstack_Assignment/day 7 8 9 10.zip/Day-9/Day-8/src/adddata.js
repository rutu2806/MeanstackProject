const promise=require("bluebird");
const mysql= require("mysql");


promise.promisifyAll(require("mysql/lib/Connection").prototype);
promise.promisifyAll(require("mysql/lib/Pool").prototype);



let read = async()=>{
    const conn=mysql.createConnection({

        user: "root",
        host:"localhost",
        database:"cdac20",
        password:""
    });

    
   await conn.connectAsync();

   let sql="delete from db where id=?";

    let result=await conn.queryAsync(sql,["7"]);

    await conn.endAsync();

    return result;
    
};

read();

