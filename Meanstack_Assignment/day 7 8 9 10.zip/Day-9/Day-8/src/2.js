const promise= require("bluebird");
const mysql= require("mysql");
const { promisifyAll } = require("bluebird");

promise.promisifyAll(require("mysql/lib/Connection").prototype);
promise.promisifyAll(require("mysql/lib/Pool").prototype);

let readme = async() => {

    const Connection=mysql.createConnection({

        user: "root",
        host : "localhost",
        database: "cdac20",
        password: ""
    });
    let sql="Select * from db"

    await Connection.connectAsync();

    let a= await Connection.queryAsync(sql);
    console.log(a);
    await Connection.endAsync();
};

readme();