var fs= require("fs");


    let readDemo = () => {

        const filepath = "./hello.txt";
        const read=fs.readFile(filepath,{encoding:"utf-8"},(err,data)=> {
            console.log(data);
        });

        
        
    };

    readDemo();


    // let readDemo1 = () => {


    //        const filepath= "./files/hello1.txt";

    //         fs.readFile(filepath,{encoding: "utf-8" },(err,data) =>{

    //             console.log("a",data);
    //         });
    //         const filepath1= "./files/hello1.txt";

    //         fs.readFile(filepath1,{encoding: "utf-8" },(err,data) =>{

    //             console.log("b",data);
    //         });
    //         const filepath2= "./files/hello1.txt";

    //         fs.readFile(filepath2,{encoding: "utf-8" },(err,data) =>{

    //             console.log("c",data);
    //         });
            
        

        
    // };

    // readDemo1();