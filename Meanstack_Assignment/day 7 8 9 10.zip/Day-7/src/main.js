const fs = require("fs");

let readdemoo =() =>{

        const filepath= "./hello.txt";

        const filedata=fs.readFileSync(filepath,{encoding: "utf-8"});
            console.log(filedata);
};

readdemoo();

let readme = () => {
try{
    
    const filepath1="./files/hello.txt";

   const filed=fs.readFileSync(filepath1,{encoding: "utf-8"});

    console.log(filed);


}
catch(err){
    console.log("error");
}

};

readme();
