const fs = require("fs");

let promise = require("bluebird");

promise.promisifyAll(fs);

let read=() =>{

    filepath = "./files/hello1.txt";

    const readme=fs.readFileAsync(filepath,{encoding: "utf-8"});
        console.log(readme);

        readme.then((data)=> {
            console.log(data);
        });
    };


read();