const fs = require ("fs");
const promise= require("bluebird");
promise.promisifyAll(fs);

let read =() =>{

    const filpth="./files/hello1.txt";

    fs.readFileAsync(filpth,{encoding: "utf-8"}).then((data)=>{
        console.log(data);
    });
    
};

read();

// const fs = require("fs");

// const Promise = require("bluebird");
// Promise.promisifyAll(fs); // Promisification of FS Module

// let readDemo = () => {
//   // fs.readFile();

//   const filePath1 = "./hello.txt";
//   // fs.readFileAsync(filePath1, { encoding: "utf-8" });
//   fs.readFileAsync(filePath1, { encoding: "utf-8" })
//     .then((data) => {
//       // file 1 done
//       console.log(data);

//       const filePath2 = "./hello.txt";
//       return fs.readFileAsync(filePath2, { encoding: "utf-8" });
//     })
//     .then((data) => {
//       // file 2 done
//       console.log(data);

//       const filePath3 = "./hello.txt";
//       return fs.readFileAsync(filePath3, { encoding: "utf-8" });
//     })
//     .then((data) => {
//       // file 3 done
//       console.log(data);
//     });
// };

// readDemo();