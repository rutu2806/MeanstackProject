const fs= require("fs");

let readdemo=() =>{

    const filepath= "./hello.txt";

        fs.readFile(filepath,{encoding: "utf-8"},(err,data)=>{

            console.log(data);

            const fp1= "./files/hello1.txt";

        const fil=fs.readFileSync(fp1,{encoding: "utf-8"});

            console.log(fil);
        });

        
};

readdemo();